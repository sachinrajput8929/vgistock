<?php 
session_start();
require_once('include/config.php');
require_once('authcation.php');
"hello ".$_SESSION['mobile'];
 "hello ".$_SESSION['username'];
 "hello ".$_SESSION['email'];
 date_default_timezone_set("Asia/Calcutta");
    $tdate = date('Y-m-d');
 $created_date = date("d-m-Y", strtotime($tdate));



if (isset($_POST['submit'])){
$staff_name=$_POST['staff_name'];
$product_name=$_POST['product_name'];
$remark=$_POST['remark'];
$quantity=$_POST['quantity'];
$status= '1';

 
$sql = "INSERT INTO vgi_product_distribution (staff_name, product_name, remark, quantity, return_request, status, given_date) VALUES ('$staff_name', '$product_name', '$remark', '$quantity', '0', '$status', '$tdate')";

   $result=mysqli_query($conn,$sql);
   if($result){
      echo "<script language='javascript'> alert ('Given Product successfully!');</script>";
    }
 }



if (isset($_POST['submit'])) {
    $product_name = $_POST['product_name'];
    $quantity = $_POST['quantity'];
    
    $sql0 = "SELECT * FROM vgi_stock WHERE product_id = '$product_name'";
    $result0 = mysqli_query($conn, $sql0);
    
    while ($data0 = mysqli_fetch_array($result0)) {
        $stock_id = $data0['product_id'];
        $st_quantity = $data0['stock_quantity'];
    }
    
    $n_quant = ($st_quantity - $quantity);
    
    $sqlu = "UPDATE vgi_stock SET stock_quantity = '$n_quant' WHERE product_id = '$product_name'";
    
    $resultu = mysqli_query($conn, $sqlu);
    
    if (!$resultu) {
        echo "Error: " . $sqlu . "<br>" . mysqli_error($conn);
    }
}

?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <title>VGI Product Distribution</title>
      <?php include_once('include/css.php'); ?>
      <style type="text/css">
         .Product tr td{
            color: black;font-weight: 500;
         }
      </style>
   </head>
   <body class="dashboard dashboard_1">
      <div class="full_container">
         <div class="inner_container">
            <?php include_once('include/header.php'); ?>
             <?php include_once('include/sidebar.php'); ?>
            <div id="content">
               <!-- dashboard inner -->
               <div class="midde_cont">
                  <div class="container-fluid">
                     <div class="row column_title">
                        <div class="col-md-12">
                           <div class="page_title">
                              <h2>  Distribution</h2>
                           </div>
                        </div>
                     </div>
                     <!-- row -->
                     <div class="row column1">
                        <div class="col-md-12">
                           <div class="white_shd full margin_bottom_30">
                              <div class="full graph_head">
                                 <div class="heading1 margin_0">
                                    <h2>Product <small>> Distribution To Staff</small></h2>
                                 </div>
                                  <div class="button_block" style="float:right;">
                                    <a href="distibution_list.php"><button type="button" class="btn" style="background:red;color: white;font-weight: 600;font-size: 15px;">Distribution List</button></a>
                                 </div>
                              </div>
                              <div class="full price_table padding_infor_info">
                                 <div class="row">
                                    <div class="col-lg-12">
                                       <div class="table-responsive-sm">
                                          <form method="post">

        <div class="row">
              <div class="col-md-6">
               <div class="form-group">
                  <label>Staff Name<sup>*</sup></label>
                  <select id="dropdown" name="staff_name" class="form-control" required>
                     <option disabled selected value>Select</option>
                     <?php
                $sql = "SELECT * FROM tbl_admin";
                $result = mysqli_query($conn,$sql);
                $i=1;
                while($data = mysqli_fetch_array($result))
                {?>
                <option value="<?php echo $data['mobile']?>">(<?php echo $i;?>)&nbsp;<?php echo $data['username']?></option>
                <?php $i++; }?>
                  </select>
               </div>
            </div>
            <div class="col-md-6">
               <div class="form-group">
                  <label>Product Name<sup>*</sup></label>
                  <select id="product" name="product_name" class="form-control" style="height: 50px;" required>
                   <option disabled selected value>Select</option>
                    <?php
                     $sql1 = "SELECT * FROM vgi_stock WHERE status='1'";
                     $result1 = mysqli_query($conn, $sql1);
                     while ($data1 = mysqli_fetch_array($result1)) {
                     $pid = $data1['product_id'];

                     $sql2 = "SELECT * FROM vgi_product WHERE id=$pid";
                     $result2 = mysqli_query($conn, $sql2);
                     $data2 = mysqli_fetch_array($result2);
                     $product_name = $data2['product_name'];
                     ?>
                     <option value="<?php echo $pid;?>"><?php echo $product_name;?></option>
                  <?php } ?>
                  </select>
               </div>
            </div>
         </div>

         <div class="row">
            <div class="col-md-6">
               <div class="form-group">
                  <label id="name-label" for="name">Quantity<sup>*</sup></label>
                <input type="number" name="quantity" id="quant"  class="form-control" required>
                <div id="error-message" style="color: red;font-weight: 800;"></div>
               </div>
            </div>

               <div class="form-group">
                   <input type="hidden" name="return_request" required>
               </div>
            
            <div class="col-md-6">
               <div class="form-group">
                  <label id="email-label" for="email">Product Distribution Date</label>
                  <input type="text" name="given_date" value="<?php echo $created_date;?>"  style="background: #c2c2c2;"  class="form-control" readonly>
               </div>
            </div>
         </div>
          

         <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                  <label id="email-label" for="email">Remarks<sup>*</sup></label>
                  <textarea  id="comments" class="form-control" name="remark" placeholder="Remark..."></textarea>
               </div>
             </div>
         </div>
         
         <div class="row">
            <div class="col-md-4">
               <button type="submit" id="submit" name="submit" class="btn" style="background:green;color: white;font-weight: 600;font-size: 15px;">Submit</button>
            </div>
         </div>

      </form>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <!-- end row -->
                     </div>
                  </div>
                  <!-- end dashboard inner -->
               </div>
            </div>
         </div>
      </div>
<?php include_once('include/bottom.php'); ?>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

 <script type="text/javascript">
 // Quantity validation on input change
$("#quant").on("input", function() {
    var inputQuantity = parseInt($(this).val());
    var responseQuantity = parseInt($('#quant').data('original-quantity'));

    if (inputQuantity > responseQuantity) {
        $('#error-message').html('Invalid Quantity Because Product Out of Stock ');
    }else if(inputQuantity < 0) {
        $('#error-message').html('Invalid Quantity Because Below Zero');
         }else if(responseQuantity == 0) {
        $('#error-message').html('sorry out of stock');
    }else {
        $('#error-message').html('');
    }
});

$("#product").change(function() {
    var pid = $(this).val();
    $.ajax({
        url: 'data.php',
        method: 'POST',
        data: {'pid': pid},
        success: function(response) {
            // Set the value of the input field
            $('#quant').val(response);

            // Store the original response quantity in a data attribute
            $('#quant').data('original-quantity', response);
        }
    });
});

  
</script>
   </body>
</html>