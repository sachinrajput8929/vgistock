<?php 
require_once("config.php");
$sessionid = $_SESSION['mobile'];
  $sessionid;
?>