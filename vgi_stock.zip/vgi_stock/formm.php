<?php 
session_start();
require_once('authcation.php');
"hello ".$_SESSION['mobile'];
 "hello ".$_SESSION['username'];
 "hello ".$_SESSION['email'];
?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <title>VGI Stock dashboard</title>
      <?php include_once('include/css.php'); ?>
      <style type="text/css">
         .Product tr td{
            color: black;font-weight: 500;
         }
      </style>
   </head>
   <body class="dashboard dashboard_1">
      <div class="full_container">
         <div class="inner_container">
            <?php include_once('include/header.php'); ?>
             <?php include_once('include/sidebar.php'); ?>
            <div id="content">
               <!-- dashboard inner -->
               <div class="midde_cont">
                  <div class="container-fluid">
                     <div class="row column_title">
                        <div class="col-md-12">
                           <div class="page_title">
                              <h2>Product</h2>
                           </div>
                        </div>
                     </div>
                     <!-- row -->
                     <div class="row column1">
                        <div class="col-md-12">
                           <div class="white_shd full margin_bottom_30">
                              <div class="full graph_head">
                                 <div class="heading1 margin_0">
                                    <h2>Product <small>>List</small></h2>
                                 </div>
                              </div>
                              <div class="full price_table padding_infor_info">
                                 <div class="row">
                                    <div class="col-lg-12">
                                       <div class="table-responsive-sm">
                                          <form id="survey-form">
         <div class="row">
            <div class="col-md-6">
               <div class="form-group">
                  <label id="name-label" for="name">Name</label>
                  <input type="text" name="name" id="name" placeholder="Enter your name" class="form-control" required>
               </div>
            </div>
            <div class="col-md-6">
               <div class="form-group">
                  <label id="email-label" for="email">Email</label>
                  <input type="email" name="email" id="email" placeholder="Enter your email" class="form-control" required>
               </div>
            </div>
         </div>
         
         <div class="row">
            <div class="col-md-6">
               <div class="form-group">
                  <label id="number-label" for="number">Age <small>(optional)</small></label>
                  <input type="number" name="age" id="number" min="10" max="99" class="form-control" placeholder="Age" >
               </div>
            </div>
            <div class="col-md-6">
               <div class="form-group">
                  <label>current role</label>
                  <select id="dropdown" name="role" class="form-control" required>
                     <option disabled selected value>Select</option>
                     <option value="student">Student</option>
                     <option value="job">Full Time Job</option>
                     <option value="learner">Full Time Learner</option>
                     <option value="preferNo">Prefer not to say</option>
                     <option value="other">Other</option>
                  </select>
               </div>
            </div>
         </div>
         
         <div class="row">
            <div class="col-md-6">
               <div class="form-group">
                  <label>Would you recommend survey to a friend?</label>
                  <div class="custom-control custom-radio custom-control-inline">
                     <input type="radio" id="customRadioInline1" value="Definitely" name="customRadioInline1" class="custom-control-input" checked="">
                     <label class="custom-control-label" for="customRadioInline1">Definitely</label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                     <input type="radio" id="customRadioInline2" value="Maybe" name="customRadioInline1" class="custom-control-input">
                     <label class="custom-control-label" for="customRadioInline2">Maybe</label>
                  </div>
                  <div class="custom-control custom-radio custom-control-inline">
                     <input type="radio" id="customRadioInline3" value="Not sure" name="customRadioInline1" class="custom-control-input">
                     <label class="custom-control-label" for="customRadioInline3">Not sure</label>
                  </div>
               </div>
            </div>

            <div class="col-md-6">
               <div class="form-group">
                  <label>This survey useful yes or no?</label>
                  <div class="custom-control custom-checkbox custom-control-inline">
                     <input type="checkbox" class="custom-control-input" name="yes" value="yes" id="yes" checked="">
                     <label class="custom-control-label" for="yes">Yes</label>
                  </div>
                  <div class="custom-control custom-checkbox custom-control-inline">
                     <input type="checkbox" class="custom-control-input" name="no" value="no" id="no">
                     <label class="custom-control-label" for="no">No</label>
                  </div>
               </div>
            </div>
         </div>


         <div class="row">
            <div class="col-md-12">
               <div class="form-group">
                  <label>Leave Message</label>
                  <textarea  id="comments" class="form-control" name="comment" placeholder="Enter your comment here..."></textarea>
               </div>
            </div>
         </div>
         
         <div class="row">
            <div class="col-md-4">
               <button type="submit" id="submit" class="btn btn-primary btn-block">Submit Survey</button>
            </div>
         </div>

      </form>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <!-- end row -->
                     </div>
                  </div>
                  <!-- end dashboard inner -->
               </div>
            </div>
         </div>
      </div>
<?php include_once('include/bottom.php'); ?>


       <script src="js/jquery.min.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <!-- wow animation -->
      <script src="js/animate.js"></script>
      <!-- select country -->
      <script src="js/bootstrap-select.js"></script>
      <!-- owl carousel -->
      <script src="js/owl.carousel.js"></script> 
      <!-- chart js -->
      <script src="js/Chart.min.js"></script>
      <script src="js/Chart.bundle.min.js"></script>
      <script src="js/utils.js"></script>
      <script src="js/analyser.js"></script>
      <!-- nice scrollbar -->
      <script src="js/perfect-scrollbar.min.js"></script>
      <script>
         var ps = new PerfectScrollbar('#sidebar');
      </script>
      <!-- custom js -->
      <script src="js/custom.js"></script>
      <script src="js/chart_custom_style1.js"></script>
   </body>
</html>